I run this on arch linux on Hyprland
run this:
- mkdir build
- cd build
- cmake ..
- make
- ./main
