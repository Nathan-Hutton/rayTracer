//-------------------------------------------------------------------------------
///
/// \file       materials.h 
/// \author     Cem Yuksel (www.cemyuksel.com)
/// \version    12.0
/// \date       October 25, 2025
///
/// \brief Example source for CS 6620 - University of Utah.
///
//-------------------------------------------------------------------------------

#ifndef _MATERIALS_H_INCLUDED_
#define _MATERIALS_H_INCLUDED_

#include "renderer.h"
#include <iostream>

//-------------------------------------------------------------------------------

class MtlBasePhongBlinn : public Material
{
public:
	void Load( Loader const &loader, TextureFileList &tfl ) override;

	void SetDiffuse   ( Color const &d ) { diffuse   .SetValue(d); }
	void SetSpecular  ( Color const &s ) { specular  .SetValue(s); }
	void SetGlossiness( float        g ) { glossiness.SetValue(g); }
	void SetEmission  ( Color const &e ) { emission  .SetValue(e); }
	void SetReflection( Color const &r ) { reflection.SetValue(r); }
	void SetRefraction( Color const &r ) { refraction.SetValue(r); }
	void SetAbsorption( Color const &a ) { absorption = a; }
	void SetIOR       ( float        i ) { ior        = i; }

	void SetDiffuseTexture   ( TextureMap *tex ) { diffuse   .SetTexture(tex); }
	void SetSpecularTexture	 ( TextureMap *tex ) { specular  .SetTexture(tex); }
	void SetGlossinessTexture( TextureMap *tex ) { glossiness.SetTexture(tex); }
	void SetEmissionTexture  ( TextureMap *tex ) { emission  .SetTexture(tex); }
	void SetReflectionTexture( TextureMap *tex ) { reflection.SetTexture(tex); }
	void SetRefractionTexture( TextureMap *tex ) { refraction.SetTexture(tex); }

	const TexturedColor& Diffuse   () const { return diffuse;    }
	const TexturedColor& Specular  () const { return specular;   }
	const TexturedFloat& Glossiness() const { return glossiness; }
	const TexturedColor& Emission  () const { return emission;   }
	const TexturedColor& Reflection() const { return reflection; }
	const TexturedColor& Refraction() const { return refraction; }

	Color Absorption     ( int mtlID=0 ) const override { return absorption; }
	float IOR            ( int mtlID=0 ) const override { return ior; }
	bool  IsPhotonSurface( int mtlID=0 ) const override { return diffuse.GetValue().Sum() > 0; }

protected:
	TexturedColor diffuse    = Color(0.5f);
	TexturedColor specular   = Color(0.7f);
	TexturedFloat glossiness = 20.0f;
	TexturedColor emission   = Color(0.0f);
	TexturedColor reflection = Color(0.0f);
	TexturedColor refraction = Color(0.0f);
	Color         absorption = Color(0.0f);
	float         ior        = 1.5f;	// index of refraction
};

//-------------------------------------------------------------------------------

class MtlPhong : public MtlBasePhongBlinn
{
public:
	Color Shade( ShadeInfo const &shadeInfo ) const override;
	void SetViewportMaterial( int mtlID=0 ) const override;	// used for OpenGL display

	bool GenerateSample( SamplerInfo const &sInfo, Vec3f &dir, Info &si ) const override;
};

//-------------------------------------------------------------------------------

class MtlBlinn : public MtlBasePhongBlinn
{
public:
	Color Shade( ShadeInfo const &shadeInfo ) const override;
	void SetViewportMaterial ( int mtlID=0 ) const override;	// used for OpenGL display

	bool GenerateSample( SamplerInfo const &sInfo, Vec3f &dir, Info &si ) const override 
    {
        float diffuseProb{ diffuse.GetValue().Gray() };
        float specularProb{ specular.GetValue().Gray() };
        float transmissiveProb{ refraction.GetValue().Gray() };

        const float totalProb{ diffuseProb + specularProb + transmissiveProb };
        if (totalProb > 1.0f)
        {
            diffuseProb /= totalProb;
            specularProb /= totalProb;
            transmissiveProb /= totalProb;
        }

        const float randomNum{ sInfo.RandomFloat() };
        if (randomNum < diffuseProb)
        {
            si.lobe = DirSampler::Lobe::DIFFUSE;
            si.mult = diffuse.GetValue();
            si.prob = diffuseProb;
            //const float geometryTerm{ sInfo.N() % sInfo.V() };
            //si.mult = diffuse.GetValue() * geometryTerm / static_cast<float>(M_PI);
            //si.prob /= 2.0f * M_PI;

            // Direction
            const float r1{ sInfo.RandomFloat() };
            const float r2{ sInfo.RandomFloat() };
            const float z{ sqrtf(r1) };
            const float sinTheta{ sqrtf(1.0f - r1) };
            const float phi{ 2.0f * M_PI * r2 };
            const float x{ sinTheta * cos(phi) };
            const float y{ sinTheta * sin(phi) };

            Vec3f u, v;
            sInfo.N().GetOrthonormals(u, v);
            dir = (x * u) + (y * v) + (z * sInfo.N());

            return true;
        }
        if (randomNum < diffuseProb + specularProb)
        {
            si.lobe = DirSampler::Lobe::SPECULAR;
            si.prob = specularProb;

            // Direction
            const float r1{ sInfo.RandomFloat() };
            const float r2{ sInfo.RandomFloat() };
            const float phi{ 2.0f * M_PI * r1 };
            const float cosTheta{ pow(r2, 1.0f / (glossiness.GetValue() + 1.0f)) };
            const float sinTheta{ sqrt(1.0f - cosTheta * cosTheta) };

            const float x{ sinTheta * cos(phi) };
            const float y{ sinTheta * sin(phi) };
            const float z{ cosTheta };

            Vec3f u, v;
            sInfo.N().GetOrthonormals(u, v);
            const Vec3f h{ (x * u) + (y * v) + (z * sInfo.N()) };

            dir = h * 2 * sInfo.V().Dot(h) - sInfo.V();
            si.mult = specular.GetValue() * dir.Dot(sInfo.N());
            return dir.Dot(sInfo.N()) > 0.0f;
        }
        if (randomNum < diffuseProb + specularProb + transmissiveProb)
        {
            const Vec3f N{ sInfo.IsFront() ? sInfo.N() : -sInfo.N() };

            si.lobe = DirSampler::Lobe::TRANSMISSION;
            //si.mult = refraction.GetValue();
            si.prob = transmissiveProb;
            
            // Direction
            const float r1{ sInfo.RandomFloat() };
            const float r2{ sInfo.RandomFloat() };
            const float phi{ 2.0f * M_PI * r1 };
            const float cosTheta{ pow(r2, 1.0f / (glossiness.GetValue() + 1.0f)) };
            const float sinTheta{ sqrt(1.0f - cosTheta * cosTheta) };

            const float x{ sinTheta * cos(phi) };
            const float y{ sinTheta * sin(phi) };
            const float z{ cosTheta };

            Vec3f u, v;
            N.GetOrthonormals(u, v);
            const Vec3f h{ (x * u) + (y * v) + (z * N) };

            const Vec3f V{ sInfo.V() };
            const float refractionRatio{ sInfo.IsFront() ? 1.0f / ior : ior };
            const float cosTheta_i{ V.Dot(h) };

            const float sinTheta_t_sq{ (refractionRatio * refractionRatio) * (1.0f - cosTheta_i * cosTheta_i) };

            if (sinTheta_t_sq > 1.0f)
            {
                si.lobe = DirSampler::Lobe::SPECULAR;

                const Vec3f V{ sInfo.V() };
                dir = h * 2 * V.Dot(h) - V;
                si.mult = refraction.GetValue() * std::abs(dir.Dot(sInfo.N()));
                return dir.Dot(N) > 0.0f;
            }

            const float cosTheta_t{ sqrtf(1.0f - sinTheta_t_sq) };

            dir = -V * refractionRatio + h * (refractionRatio * cosTheta_i - cosTheta_t);
            si.mult = refraction.GetValue() * std::abs(dir.Dot(sInfo.N()));

            return dir.Dot(N) < 0.0f;
        }
        return false;

    }
};

//-------------------------------------------------------------------------------

class MtlMicrofacet : public Material
{
public:
	void Load( Loader const &loader, TextureFileList &tfl ) override;

	void SetBaseColor    ( Color const &c ) { baseColor    .SetValue(c); }
	void SetRoughness    ( float        r ) { roughness    .SetValue(r); }
	void SetMetallic     ( float        m ) { metallic     .SetValue(m); }
	void SetEmission     ( Color const &e ) { emission     .SetValue(e); }
	void SetTransmittance( Color const &t ) { transmittance.SetValue(t); }
	void SetAbsorption   ( Color const &a ) { absorption = a; }
	void SetIOR          ( float        i ) { ior        = i; }

	void SetBaseColorTexture    ( TextureMap *tex ) { baseColor    .SetTexture(tex); }
	void SetRoughnessTexture    ( TextureMap *tex ) { roughness    .SetTexture(tex); }
	void SetMetallicTexture     ( TextureMap *tex ) { metallic     .SetTexture(tex); }
	void SetEmissionTexture     ( TextureMap *tex ) { emission     .SetTexture(tex); }
	void SetTransmittanceTexture( TextureMap *tex ) { transmittance.SetTexture(tex); }

	Color Shade( ShadeInfo const &shadeInfo ) const override;
	Color Absorption         ( int mtlID=0 ) const override { return absorption; }
	float IOR                ( int mtlID=0 ) const override { return ior;        }
	bool  IsPhotonSurface    ( int mtlID=0 ) const override { return baseColor.GetValue().Sum() > 0; }
	void  SetViewportMaterial( int mtlID=0 ) const override;	// used for OpenGL display

	bool GenerateSample( SamplerInfo const &sInfo, Vec3f &dir, Info &si ) const override;

private:
	TexturedColor baseColor     = Color(0.5f);	// albedo for dielectrics, F0 for metals
	TexturedFloat roughness     = 1.0f;
	TexturedFloat metallic      = 0.0f;
	TexturedColor emission      = Color(0.0f);
	TexturedColor transmittance = Color(0.0f);
	Color         absorption    = Color(0.0f);
	float         ior           = 1.5f;	// index of refraction
};

//-------------------------------------------------------------------------------

class MultiMtl : public Material
{
public:
	virtual ~MultiMtl() { for ( Material *m : mtls ) delete m; }

	Color Shade( ShadeInfo const &sInfo ) const override { int m=sInfo.MaterialID(); return m<(int)mtls.size() ? mtls[m]->Shade(sInfo) : Color(1,1,1); }
	Color Absorption         ( int mtlID=0 ) const override { return mtlID<(int)mtls.size() ? mtls[mtlID]->Absorption     (mtlID) : Material::Absorption     (mtlID); }
	float IOR                ( int mtlID=0 ) const override { return mtlID<(int)mtls.size() ? mtls[mtlID]->IOR            (mtlID) : Material::IOR            (mtlID); }
	bool  IsPhotonSurface    ( int mtlID=0 ) const override { return mtlID<(int)mtls.size() ? mtls[mtlID]->IsPhotonSurface(mtlID) : Material::IsPhotonSurface(mtlID); }
	void  SetViewportMaterial( int mtlID=0 ) const override { if   ( mtlID<(int)mtls.size() ) mtls[mtlID]->SetViewportMaterial(); }

	void AppendMaterial( Material *m ) { mtls.push_back(m); }

	bool GenerateSample( SamplerInfo const &sInfo, Vec3f &dir, Info &si ) const override
	{
		int m = sInfo.MaterialID();
		if ( m < (int)mtls.size() ) return mtls[m]->GenerateSample(sInfo,dir,si);
		else return Material::GenerateSample(sInfo,dir,si);
	}

private:
	std::vector<Material*> mtls;
};

//-------------------------------------------------------------------------------

#endif
