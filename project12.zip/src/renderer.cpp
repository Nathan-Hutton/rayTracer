#include "renderer.h"

Renderer renderer;
const bool doingDirectWithPhotonMapping{ true };
const bool doingIndirectWithPhotonMapping{ false };
const bool doingCaustics{ false };
const bool monteCarloWithPhoton{ true };
