Ran on arch linux with hyprland
Run these commands:
mkdir build
cd build
cmake ..
make
./main
