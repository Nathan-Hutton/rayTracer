#include "renderer.h"

Renderer renderer;
const bool doingDirectWithPhotonMapping{ false };
const bool doingIndirectWithPhotonMapping{ true };
const bool doingCaustics{ true };
const bool monteCarloWithPhoton{ false };
